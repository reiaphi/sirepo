<html>
<h3>INI HALAMAN DEMO</h3>
File:
<?php if (!empty($file_aplikasi)) {
    echo $file_aplikasi->name;
} else {
    echo "empty";
}
?>

</html>